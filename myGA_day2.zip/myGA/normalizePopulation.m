function normalized=normalizePopulation(unnormalized,V,M,lb,ub)
    normalized = (unnormalized - lb) ./ (ub - lb);
end