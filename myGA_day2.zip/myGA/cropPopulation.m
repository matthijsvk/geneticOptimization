function new=cropPopulation(old,nb)
    new = old(1:nb,:);
end
