function children=geneticOperators(parents,NC,P,sd_mut,intervalScalar,V,M,f,lb,ub)

    PS=size(parents,1);
    
    children = [];
    for i=1:NC
        create_child = randi([0,1]);
        if create_child > P
            % select parents randomly
            twoParentsRows = randi([1,PS],2,1);
            twoParents = parents(twoParentsRows,:);
            firstParent = twoParents(1,1:V);
            secondParent = twoParents(2,1:V);

            % RECOMBINATION
            % interpolate between parents
            t= randi([0,1],1,V);
            
            interval = [firstParent; secondParent];
            intervalCenter = (interval(1,:) + interval (2,:))/2;
            intervalZeroCentered = interval -  intervalCenter;
            intervalZeroCenteredScaled = intervalZeroCentered * intervalScalar;
            intervalScaled = intervalZeroCenteredScaled + intervalCenter;
            
            child = t .* intervalScaled(1,:) + (1-t) .* intervalScaled(2,:);
            
            % binary: concatenate parents
%             splitLocation = randi([2,V]);
%             child = [firstParent(1,1:splitLocation-1), secondParent(1,splitLocation:V)];

            % MUTATION
            sd = sd_mut;      % standard deviation
            child = sd.*randn(1,V) + child;  %child is mean value        

            % clip all the values in [0,1]
            child = max(0,child);
            child = min(1,child);
            
            % rank of the child is 1 to start off
            child(1,V+M+1) = 1;
            % crowding distance of child is 0 to start off
            child(1,V+M+2) = 0;
         
            % add to children matrix
            children = [children ; child];
        end
    end
    
    % evaluate the children
    children = evaluatePopulation(children,f,V,M,lb,ub);
end
