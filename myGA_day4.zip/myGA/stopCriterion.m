function flag=stopCriterion(it,oldPopulationObjectives, newPopulationObjectives, notChangingLimit)
% Return :  1 if the GA must continue 
%           0 if the GA must stop

    flag=1;
    if it > 10000
        flag=0;
    end

%     % normalize the objective columns relative to each other (so we don't prioritize
%     % columns with large values)
%     ub = max(oldPopulationObjectives);
%     lb = min(oldPopulationObjectives);
%     normalizedOld = normalizePopulation(oldPopulationObjectives, lb, ub);
%     
%     ub = max(newPopulationObjectives);
%     lb = min(newPopulationObjectives);
%     normalizedNew = normalizePopulation(newPopulationObjectives, lb, ub);
%     
%     difference = normalizedOld - normalizedNew;
%     changes = mean(mean(difference))
%     
%     % find elements that have too low crowdingFactor, and mutate them more
%     
%     
%     if changes < notChangingLimit
%         flag = 0;
%     end
    
    
    
end