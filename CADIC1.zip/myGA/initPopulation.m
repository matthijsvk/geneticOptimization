function population=initPopulation(N,V)
%initPopulation(N,V)

   
end
