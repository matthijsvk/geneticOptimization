function children=geneticOperators(parents,NC,P,V,M,f,lb,ub)

PS=size(parents,1);


end
