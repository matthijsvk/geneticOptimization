function new=cropPopulation(old,nb)


end
