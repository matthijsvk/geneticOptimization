function selection=selectionTournament(population,NP,V,M)

end
