clear all;
clf;

% Define the boundaries of the problem.
lb=[-5 -5];
ub=[5 5];

% Use the GA
res=myGA(@(x) benchmark(2,x),2,1,lb,ub);

