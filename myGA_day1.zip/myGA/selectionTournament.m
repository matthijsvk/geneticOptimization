function selection=selectionTournament(population,NP,V,M)
    %% Tournament Selection
    selection = [];
    popSize = size(population);
    popSize = popSize(1);
    for i=1:NP
        competitorsRows = randi([1,popSize],2);
        competitors = population(competitorsRows);
        if competitors(1,end) < competitors(2,end) % lower = better (minimize)
            selected = competitors(1);
        else
            selected = competitors(2);
        end
        selection = [selection; selected];
    end

%     %% Select best NP_best and add some random others to prevent local
%     minima
%     NP_best = round(NP * 0.8);
%     NP_random = NP - NP_best;
%     selection = population(1:NP_best,:)
%     
%     population_without_best = population(NP_best+1:end,:);
%     c = randperm(length(population),NP_random)  
%     random_selected = population(c,:)  % output matrix
%     
%     selection = [selection; random_selected]
end
