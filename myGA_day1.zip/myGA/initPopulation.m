function population=initPopulation(N,V)
    
population = random('uniform',0,1,N,V);
   
end
