function population=evaluatePopulation(population,f,V,M,lb,ub)
    population = population(:,1:V);
    population = unnormalizePopulation(population, V,M,lb,ub);
    
    scores = f(population);
    
    population = normalizePopulation(population, V,M,lb,ub);
    population = [population,scores];
end
