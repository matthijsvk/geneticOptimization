% MICAS Mentor AMS 2014.1
% Based on : Ben Geeraerts, February 26th 2015
% Update : Anthony Coyette, November 2015
% 	   Matlab version

D='/esat/micas-data/software/ams_2014.1';
setenv('MGC_AMS_HOME',D);
setenv('PATH', [ D '/modeltech/bin:' D '/bin:' getenv('PATH') ]);
setenv('MGLS_LICENSE_FILE', '1717@licserv');

