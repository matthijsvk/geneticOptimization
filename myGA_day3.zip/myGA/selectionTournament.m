function selection=selectionTournament(population,NP,V,M)
    %% Tournament Selection
    popSize = size(population);
    popSize = popSize(1);
    
    selection = [];
    for i=1:NP
        competitorsRows = randi([1,popSize],2,1);
        competitors = population(competitorsRows,:);
    
        selected = selectBest(competitors(1,:), competitors(2,:), V, M);
        
        selection = [selection; selected];
    end

%     %% Select best NP_best and add some random others to prevent local
%     minima
%     NP_best = round(NP * 0.8);
%     NP_random = NP - NP_best;
%     selection = population(1:NP_best,:)
%     
%     population_without_best = population(NP_best+1:end,:);
%     c = randperm(length(population),NP_random)  
%     random_selected = population(c,:)  % output matrix
%     
%     selection = [selection; random_selected]
end


function selected = selectBest(a,b,V, M)
% MYMEAN Example of a local function.
    if M==1
        rankColumn = V+1; %only one column with scores
    else
        rankColumn = V+M+1;
    end
    
    if a(1,rankColumn) < b(1,rankColumn) % lower rank = better
        selected = a;
    else
        selected = b;
    end
end
